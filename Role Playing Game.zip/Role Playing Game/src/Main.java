package com.company;

public class Main {

    public static void main(String[] args) {
        com.company.Game game = new com.company.Game();
        game.startGame();
    }
}