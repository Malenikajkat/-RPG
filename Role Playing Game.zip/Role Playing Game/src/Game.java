package com.company;
import com.company.Entity;
import com.company.Hero;
import com.company.Trader;
import com.company.Battle;
import java.util.Scanner;
public class Game {

    Game(){}

    public void startGame(){
        System.out.println("Добро пожаловать в мир приключений! Тебя ждет много увлекательных приключений!\nКак тебя зовут?");
        Scanner scanner = new Scanner(System.in);
        Hero hero = new Hero(scanner.nextLine());
        Trader trader= new Trader();
        System.out.println("Вы создали персонажа!" + "\n" + hero);
        outterLoop : while (true){
            System.out.println("Куда пойдем?\n1. К торговцу\n2. Мрачная чаща\n3. Выход");
            int move = scanner.nextInt();
            switch (move){
                case 1:
                    trader.bargain();
                    System.out.println(String.format("Текущий показатель здоровья %s/%s / Золото - %s", hero.getHealth(), hero.getMaxHealth(), hero.getGold()));
                    while (true){
                        int num = scanner.nextInt();
                        if (num != 1 && num != 2 && num != 3){
                            break;
                        }
                        if (hero.getGold() >= num * 100){
                            hero.minusGold(num * 100);
                            trader.addMoney(num * 100);
                            hero.addHealth(num * 70);
                            System.out.println(String.format("Здоровье востановлено, текущий показатель %s/%s\nОсталось золота - %s", hero.getHealth(), hero.getMaxHealth(), hero.getGold()));
                        }else {
                            System.out.println("Приходи в следующий раз");
                            continue;
                        }
                    }
                    break;
                case 2:
                    while (true) {
                        com.company.Entity enemy = Math.random() > 0.5 ? new com.company.Skeleton("Fredi") : new com.company.Goblin("Giros");
                        System.out.println(String.format("Вы зашли в мрачную чащу и встретили там\n%s\n1. Вступить в бой\n2. Спасаться бегством", enemy));
                        switch (scanner.nextInt()) {
                            case 1:
                                Thread fight = new Battle(hero, enemy);
                                fight.start();
                                try {
                                    fight.join();
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                                if (hero.getHealth() <= 0) {
                                    System.out.println("Game over");
                                    break outterLoop;
                                }
                                break;
                            default:
                                continue;
                        }
                        System.out.println("Куда дальше?\n1 - Продолжить бой\n2 - Вернуться в город\n");
                        if (scanner.nextInt() == 1) continue;
                        break;

                    }
                    break;
                case 3:
                    System.out.println("До новых встреч, в нашем волшебном мире!");
                    break outterLoop;
                default:
                    System.out.println("I'll be back");
            }
        }
    }
}