package com.company;

public class Trader {
    private int money;

    Trader(){
        money = 0;
    }

    public void bargain(){
        System.out.println("Приветсвую герой! У меня есть все необходимое для тебя, выбирай!" +
                "\n1 - Малое зелье исценения 50g (+ 100 hp)\n2 - Среднее зелье исценения 200g (+ 400 hp)\n3 - Мощное зелье исценения 500g (+ 1000 hp)\n4 - Вернуться");
    }

    public void addMoney(int money){
        this.money += money;
        System.out.println("Был рад помочь!");
    }
}