package com.company;
import com.company.Entity;


import java.util.Random;

public class Skeleton extends Entity {
    Skeleton(String name) {
        super(name, "Skeleton", 1);
        this.addExperience(this.getLevel() * 100);
        this.addGold(new Random().nextInt(1000));
    }
}