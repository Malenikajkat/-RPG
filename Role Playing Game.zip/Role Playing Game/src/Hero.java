package com.company;
import com.company.Entity;

public class Hero extends Entity {
    Hero(String name) {
        super(name, "Human", 2);
    }
}